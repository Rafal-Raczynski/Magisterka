﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MatNETIO.common;

namespace MatNETIO.types
{
    /// <summary>
	/// This class represents an Int16 (short) array (matrix)
	/// </summary>
	public class MLInt16 : MLNumericArray<short>
    {
        #region Constructors

        /// <summary>
        /// Normally this constructor is used only by <c>MatFileReader</c> and <c>MatFileWriter</c>
        /// </summary>
        /// <param name="Name">Array name</param>
        /// <param name="Dims">Array dimensions</param>
        /// <param name="Type">Array type: here <c>mxINT16_CLASS</c></param>
        /// <param name="Attributes">Array flags</param>
        public MLInt16(string Name, int[] Dims, int Type, int Attributes)
            : base(Name, Dims, Type, Attributes) { }

        /// <summary>
        /// Create a <c>MLInt16</c> array with given name and dimensions.
        /// </summary>
        /// <param name="Name">Array name</param>
        /// <param name="Dims">Array dimensions</param>
        public MLInt16(string Name, int[] Dims)
            : base(Name, Dims, MLArray.mxINT16_CLASS, 0) { }

        /// <summary>
        /// <a href="http://math.nist.gov/javanumerics/jama/">Jama</a> [math.nist.gov] style:
        /// construct a 2D real matrix from a one-dimensional packed array.
        /// </summary>
        /// <param name="Name">Array name</param>
        /// <param name="vals">One-dimensional array of <c>short</c>, packed by columns</param>
        /// <param name="m">Number of rows</param>
        public MLInt16(string Name, short[] vals, int m)
            : base(Name, MLArray.mxINT16_CLASS, vals, m) { }

        /// <summary>
        /// <a href="http://math.nist.gov/javanumerics/jama/">Jama</a> [math.nist.gov] style:
        /// construct a 2D real matrix from <c>short[][]</c>.
        /// </summary>
        /// <remarks>Note: Array is converted to <c>short[]</c></remarks>
        /// <param name="Name">Array name</param>
        /// <param name="vals">Two-dimensional array of values</param>
        public MLInt16(string Name, short[][] vals)
            : this(Name, Helpers.Array2DTo1D<short>(vals), vals.Length) { }

        /// <summary>
        /// <a href="http://math.nist.gov/javanumerics/jama/">Jama</a> [math.nist.gov] style:
        /// construct a 2D imaginary matrix from a one-dimensional packed array.
        /// </summary>
        /// <param name="Name">Array name</param>
        /// <param name="Real">One-dimensional array of <c>short</c> for <i>real</i> values, packed by columns</param>
        /// <param name="Imag">One-dimensional array of <c>short</c> for <i>imaginary</i> values, packed by columns</param>
        /// <param name="M">Number of rows</param>
        public MLInt16(string Name, short[] Real, short[] Imag, int M)
            : base(Name, MLArray.mxINT16_CLASS, Real, Imag, M) { }


        /// <summary>
        /// <a href="http://math.nist.gov/javanumerics/jama/">Jama</a> [math.nist.gov] style:
        /// construct a 2D imaginary matrix from a one-dimensional packed array.
        /// </summary>
        /// <param name="Name">Array name</param>
        /// <param name="Real">One-dimensional array of <c>short</c> for <i>real</i> values, packed by columns</param>
        /// <param name="Imag">One-dimensional array of <c>short</c> for <i>imaginary</i> values, packed by columns</param>
        public MLInt16(string Name, short[][] Real, short[][] Imag)
            : this(Name, Helpers.Array2DTo1D<short>(Real), Helpers.Array2DTo1D<short>(Imag), Real.Length) { }

        #endregion

        /// <summary>
        /// Builds a numeric object from a byte array.
        /// </summary>
        /// <param name="bytes">A byte array containing the data.</param>
        /// <returns>A numeric object</returns>
        protected override object BuildFromBytes2(byte[] bytes)
        {
            return BitConverter.ToInt16(bytes, 0);
        }

        /// <summary>
        /// Gets a byte array from a numeric object.
        /// </summary>
        /// <param name="val">The numeric object to convert into a byte array.</param>
        public override byte[] GetByteArray(object val)
        {
            return BitConverter.GetBytes((short)val);
        }
    }
}
